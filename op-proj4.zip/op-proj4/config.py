import os

# Database initialization
basedir = os.path.abspath(os.path.dirname(__file__))
if os.environ.get('DATABASE_URL') is None:
    SQLALCHEMY_DATABASE_URI = 'postgres://op_proj3:12345@localhost/op_proj3'
else:
    SQLALCHEMY_DATABASE_URI = os.environ['DATABASE_URL']
