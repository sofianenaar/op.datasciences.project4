import datetime

from flask import Flask, request, redirect
from flask import render_template

app = Flask(__name__)

# Config options - Make sure you created a 'config.py' file.
app.config.from_object('config')
# To get one variable, tape app.config['MY_VARIABLE']

from .utils import get_predictor, binarize, scale, \
    fetch_resource


@app.route('/flight-delays-prediction')
def delay_predictions_index():
    return render_template('fdelays.html')


@app.route('/resource/<what>')
def get_resource(what):
    return fetch_resource(what)


@app.route('/')
def hello():
    return redirect("flight-delays-prediction")


@app.route('/predict')
def redir():
    return redirect("flight-delays-prediction")


@app.route('/predict', methods=['post'])
def predict_delay():
    start_airport = request.form['start_airport'].split(" - ")[1]
    carrier = request.form['carrier']
    date_ = request.form['date_']
    time_ = int(request.form['time_'])
    date_time = datetime.datetime.strptime(date_, '%Y-%m-%d')
    day = date_time.day
    day_of_week = date_time.weekday()  # todo lundi = 0
    month = date_time.month

    print(start_airport, carrier, date_, time_, date_time, day, month, day_of_week)
    df = binarize(month, day, day_of_week, carrier, time_, start_airport)
    x = scale(df)
    p = get_predictor()
    delay = round(p.predict(x)[0], 2)
    print("Estimation : ", delay)
    return render_template('fdelays.html', value=delay)
