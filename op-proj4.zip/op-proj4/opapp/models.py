import pickle


# load an object from an .pkl file
def from_pkl(name):
    with open('./opapp/pkl/' + name + '.pkl', 'rb') as f:
        return pickle.load(f)


class Supplier:
    instances = {}

    def __init__(self):
        if len(self.instances) == 0:
            for obj in ["best_model", "dummies_columns", "scaler", "airports_with_cities", "hours", "carriers"]:
                self.instances[obj] = from_pkl(obj)

    def get(self, what):
        return self.instances[what]
