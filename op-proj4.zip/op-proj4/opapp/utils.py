import numpy
import pandas as pd
from flask import jsonify

from opapp.models import Supplier


def get_predictor():
    best_model = Supplier().get('best_model')
    print('alpha: ', best_model.alpha, '            penalty:', best_model.penalty, '       loss:', best_model.loss)
    return best_model


def binarize(month, day, day_of_week, carrier, time_, start_airport):
    col = Supplier().get('dummies_columns')
    df = pd.DataFrame(columns=col)
    df.loc[0] = 0
    df["MONTH_" + str(month)] = 1
    df["DAY_OF_MONTH_" + str(day)] = 1
    df["DAY_OF_WEEK_" + str(day_of_week)] = 1
    df["UNIQUE_CARRIER_" + str(carrier)] = 1
    df["ORIGIN_AIRPORT_ID_" + str(start_airport)] = 1
    df["CRS_DEP_TIME_" + str(time_)] = 1
    # todo add numeric features
    return df


def scale(df):
    return Supplier().get('scaler').transform(df)


def fetch_resource(what):
    result = [int(x) if isinstance(x, numpy.int64) or isinstance(x, numpy.int32) else x for x in Supplier().get(what)]
    return jsonify(
        result=result
    )
